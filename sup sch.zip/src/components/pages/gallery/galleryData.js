const gallerydata = [
    {
        alt:"pic",
        img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYvEqrKNhZP_A-p_dwklWZsJpJG8fW6X8dng&usqp=CAU",
    },
    {
        alt:"pic",
        img: "https://t3.ftcdn.net/jpg/02/92/82/52/360_F_292825201_orpokDry0uBpw5IB3QQTAtP7dI84gLuL.jpg",
    },
    {
        alt:"pic",
        img: "https://thumbs.dreamstime.com/b/cute-boy-backpack-walking-to-school-cartoon-style-international-students-day-concept-image-generated-using-ai-tool-289346700.jpg",
    },
    {
        alt:"pic",
        img: "https://cdn.pixabay.com/photo/2023/03/04/20/44/student-cartoon-7830116_1280.png",
    },
    {
        alt:"pic",
        img: "https://img.freepik.com/premium-vector/kid-education-vector-illustration-designvector-illustrations-cute-kids-with-colored-pencils_723224-2786.jpg",
    },
    {
        alt:"pic",
        img: "https://i.ytimg.com/vi/fLw-8kQ0IEY/maxresdefault.jpg",
    },
    {
        alt:"pic",
        img: "https://static.vecteezy.com/system/resources/previews/021/948/562/non_2x/character-happy-activity-ai-generated-free-photo.jpg",
    },
    {
        alt:"pic",
        img: "https://png.pngtree.com/background/20240413/original/pngtree-primary-school-students-happy-going-to-school-cartoon-illustration-picture-image_8469609.jpg",
    },
    {
        alt:"pic",
        img: "https://png.pngtree.com/thumb_back/fh260/background/20230705/pngtree-little-girl-happy-going-to-school-illustration-image_4478703.jpg",
    },
    {
        alt:"pic",
        img: "https://png.pngtree.com/background/20231222/original/pngtree-primary-school-students-go-to-school-background-illustration-picture-image_6939061.jpg",
    },
    {
        alt:"pic",
        img: "https://img.freepik.com/premium-photo/spooky-halloween-background-with-pumpkins-cemetery_717710-1251.jpg",
    },
    {
        alt:"pic",
        img: "https://t4.ftcdn.net/jpg/03/19/48/09/360_F_319480933_XhNAPFu0ozP8MQ9DZR5PXyEpvUGff1T3.jpg",
    },
    {
        alt:"pic",
        img: "https://img.freepik.com/premium-photo/illustration-children-s-activities-back-school_566246-12087.jpg",
    },
    {
        alt:"pic",
        img: "https://img.freepik.com/premium-photo/illustration-children-s-activities-back-school_566246-12193.jpg?size=626&ext=jpg&ga=GA1.1.2113030492.1711843200&semt=ais",
    },
]

export default gallerydata;