import React from 'react'
import './imagefix.css'

function Imagefix() {
  return (
    <div className='For_Background_Image'>
      
      <div className="imagefix1"><h1>Tell Us What Are You Looking For</h1>
      <h3 className='h3-content'>It strives to deliver value-based quality education and imbibe top-class management skills</h3>
      <button className='contact_us_button'>CONTACT US</button>
      </div>
      
    </div>
  )
}

export default Imagefix
